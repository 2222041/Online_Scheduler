from .online_scheduler import main

__copyright__    = 'Copyright (C) 2018 Your Name'
__version__      = '0.1.2'
__license__      = 'BSD-3-Clause'
__author__       = 'Your Name'
__author_email__ = 'Your@Email'
__url__          = 'http://github.com/account/repository'

__all__ = ['main', ...]